import { Component } from '@angular/core';

@Component({
  selector: 'app-oneclient',
  templateUrl: './oneclient.component.html',
  styleUrls: ['./oneclient.component.css']
})
export class OneclientComponent {

}
