import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgToastModule } from 'ng-angular-popup';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { MatTableModule } from '@angular/material/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { ClientinfoComponent } from './clientinfo/clientinfo.component';
import { ProjectsinfoComponent } from './projectsinfo/projectsinfo.component';

import { EntrypageComponent } from './entrypage/entrypage.component';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { OneclientComponent } from './oneclient/oneclient.component';
import { ModifyclientComponent } from './modifyclient/modifyclient.component';





@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    LoginComponent,
    HomeComponent,
    ClientinfoComponent,
    ProjectsinfoComponent,
    EntrypageComponent,
    OneclientComponent,
    ModifyclientComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    NgbModule,
    BrowserAnimationsModule,
    MatTabsModule,
    MatIconModule,
    MatTableModule,
    FormsModule,
    HttpClientModule,
    NgToastModule,

    MatFormFieldModule,
    MatInputModule,







  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
