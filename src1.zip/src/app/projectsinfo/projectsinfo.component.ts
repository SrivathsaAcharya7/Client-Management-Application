import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { Project } from '../project';
import { Projectservice } from '../projectservice';


@Component({
  selector: 'app-projectsinfo',
  templateUrl: './projectsinfo.component.html',
  styleUrls: ['./projectsinfo.component.css']
})
export class ProjectsinfoComponent implements OnInit {

  constructor(
    private proService: Projectservice,
    private router: Router,
    private toast: NgToastService
  ) {}

  prodetails: Project[] = [];
  displayedColumns: string[] = ['ID', 'ProjectName', 'Duration', 'ClientID'];

  ngOnInit(): void {
    this.showAllProjectDetails()
  }

  showAllProjectDetails() {
    this.proService.showAllProjects().subscribe((data) => {
      this.prodetails = data;
    });
  }

}
