import { Projectservice } from './projectservice';

describe('Projectservice', () => {
  it('should create an instance', () => {
    expect(new Projectservice()).toBeTruthy();
  });
});
