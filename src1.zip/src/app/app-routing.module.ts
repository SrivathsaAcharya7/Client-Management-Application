import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ClientinfoComponent } from './clientinfo/clientinfo.component';
import { ProjectsinfoComponent } from './projectsinfo/projectsinfo.component';

const routes: Routes = [

{path:"",component:WelcomeComponent},
{path:"welcome",component:WelcomeComponent},
{path:"login",component:LoginComponent},
{path:"home",component:HomeComponent},
{path:"clientinfo",component:ClientinfoComponent},
{path:"projectsinfo",component:ProjectsinfoComponent}



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
