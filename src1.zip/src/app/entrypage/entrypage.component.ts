import { Component, OnInit } from '@angular/core';
import { ClientinfoService } from '../clientinfo.service';
import { Router } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { Client } from '../client';
import { Projectservice } from '../projectservice';
import { Project } from '../project';

@Component({
  selector: 'app-entrypage',
  templateUrl: './entrypage.component.html',
  styleUrls: ['./entrypage.component.css']
})
export class EntrypageComponent implements OnInit {

  constructor(
    private cliService: ClientinfoService,
    private proService: Projectservice,
    private router: Router,
    private toast: NgToastService
  ) {}

  clidetails: Client[] = [];
  displayedColumns: string[] = ['ID', 'ClientName', 'Address', 'Email','Password'];

  prodetails: Project[] = [];
  displayedColumn: string[] = ['ID', 'ProjectName', 'Duration', 'ClientID'];

  ngOnInit(): void {
    this.showAllClientsDetails()
    this.showAllProjectDetails()
  }

  showAllClientsDetails() {
    this.cliService.showAllClients().subscribe((data) => {
      this.clidetails = data;
    });
  }
  showAllProjectDetails() {
    this.proService.showAllProjects().subscribe((data) => {
      this.prodetails = data;
    });
  }

}
