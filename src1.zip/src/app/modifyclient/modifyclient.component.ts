import { Component } from '@angular/core';

@Component({
  selector: 'app-modifyclient',
  templateUrl: './modifyclient.component.html',
  styleUrls: ['./modifyclient.component.css']
})
export class ModifyclientComponent {

}
